<h3 class="text-center"><span class="glyphicon glyphicon-open"></span><hr>Upload secara bersamaan ke semua Microtock Anda</h3>
	<div style="margin: 10px auto; width: 350px;" class="panel panel-default">
		<div class="panel-body">
			<form class="form-horizontal" action="index.php" method="post">
				<div class="form-group">
				    <label class="col-sm-4 control-label">Email</label>
				    <div class="col-sm-8">
				      <input type="text" name="username" class="form-control" placeholder="Username">
				    </div>
				</div>
				<div class="form-group">
				    <label class="col-sm-4 control-label">Password</label>
				    <div class="col-sm-8">
				      <input type="password" name="password" class="form-control" placeholder="Password">
				    </div>
				</div>
				<div class="form-group">
				    <div class="col-sm-offset-4 col-sm-8">
				      <button type="submit" name="logindata" value="1" class="btn btn-default">Sign in</button>
				    </div>
				</div>
			</form>
	  </div>
	</div>